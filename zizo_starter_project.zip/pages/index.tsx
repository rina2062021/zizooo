
export default function Home() {
  return <h1>Hello from Next.js + Firebase Starter!</h1>;
}
